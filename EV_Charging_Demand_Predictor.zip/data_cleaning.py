
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

data = pd.read_csv('data/ev_charging_cleaned.csv')

print("Dataset Shape:", data.shape)

print("\nDataset Information:")
print(data.info())

print("\nStatistical Summary:")
print(data.describe())

print("\nEnergy Consumed Summary:")
print(data['Energy Consumed (kWh)'].describe())

plt.figure(figsize=(8, 5))
sns.histplot(data['Energy Consumed (kWh)'], kde=True)
plt.title('Distribution of Energy Consumed')
plt.xlabel('Energy Consumed (kWh)')
plt.ylabel('Frequency')
plt.show()
