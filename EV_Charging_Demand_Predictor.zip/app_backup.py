
import streamlit as st
import pandas as pd
import joblib

# PAGE CONFIGURATION

st.set_page_config(
    page_title='EV Charging Demand Predictor',
    page_icon='⚡',
    layout='wide'
)

# LOAD MODEL AND DATA

model = joblib.load('best_model.pkl')
data = pd.read_csv('data/ChargingRecords.csv')

# PAGE TITLE

st.title('⚡ EV Charging Demand Predictor')
st.write('Predict EV charging demand using charger and time details.')

st.divider()

# DATASET OVERVIEW

col1, col2, col3 = st.columns(3)

with col1:
    st.metric('Total Records', f'{len(data):,}')

with col2:
    st.metric('Charging Locations', data['Location'].nunique())

with col3:
    st.metric('Charger Types', data['ChargerType'].nunique())

st.divider()

# SIDEBAR: PREDICTION INPUTS

st.sidebar.header('Charging Details')

charger_id = st.sidebar.selectbox(
    'Charger ID',
    sorted(data['ChargerID'].dropna().unique().tolist())
)

charger_company = st.sidebar.selectbox(
    'Charger Company',
    sorted(data['ChargerCompany'].dropna().unique().tolist())
)

location = st.sidebar.selectbox(
    'Location',
    sorted(data['Location'].dropna().unique().tolist())
)

charger_type = st.sidebar.selectbox(
    'Charger Type',
    sorted(data['ChargerType'].dropna().unique().tolist())
)

start_day = st.sidebar.date_input('Charging Date')
start_time = st.sidebar.time_input('Charging Start Time')

# PREDICTION

st.subheader('Demand Prediction')

st.write(
    'Select the charging details in the sidebar and click the button.'
)

if st.button('Predict Demand', type='primary'):

    input_data = pd.DataFrame([{
        'ChargerID': charger_id,
        'ChargerCompany': charger_company,
        'Location': location,
        'ChargerType': charger_type,
        'StartHour': start_time.hour,
        'StartDay': start_day.weekday()
    }])

    prediction = model.predict(input_data)[0]

    st.success('Prediction completed successfully')

    result_col1, result_col2 = st.columns(2)

    with result_col1:
        st.metric(
            'Predicted Charging Demand',
            f'{prediction:.2f}'
        )

    with result_col2:
        st.write('**Selected Charger:**', charger_id)
        st.write('**Selected Location:**', location)
        st.write(
            '**Charging Time:**',
            start_time.strftime('%H:%M')
        )

# CHARGING DATA INSIGHTS

st.divider()

st.header('Charging Data Insights')

# SIDEBAR: CHART FILTERS

st.sidebar.divider()
st.sidebar.header('Chart Filters')

selected_company = st.sidebar.selectbox(
    'Filter by Charger Company',
    ['All Companies'] +
    sorted(data['ChargerCompany'].dropna().unique().tolist())
)

selected_type = st.sidebar.selectbox(
    'Filter by Charger Type',
    ['All Types'] +
    sorted(data['ChargerType'].dropna().unique().tolist())
)

filtered_data = data.copy()

if selected_company != 'All Companies':
    filtered_data = filtered_data[
        filtered_data['ChargerCompany'] == selected_company
    ]

if selected_type != 'All Types':
    filtered_data = filtered_data[
        filtered_data['ChargerType'] == selected_type
    ]

st.write(
    'Records matching selected filters:',
    f'{len(filtered_data):,}'
)

# CHART 1: AVERAGE DEMAND BY CHARGER TYPE

st.subheader('Average Demand by Charger Type')

if not filtered_data.empty:
    demand_by_type = (
        filtered_data.groupby('ChargerType')['Demand']
        .mean()
    )

    st.bar_chart(demand_by_type)
else:
    st.warning('No records available for the selected filters.')

# CHART 2: CHARGING RECORDS BY START HOUR

st.subheader('Charging Records by Start Hour')

if not filtered_data.empty:

    filtered_data = filtered_data.copy()

    filtered_data['StartHour'] = pd.to_datetime(
        filtered_data['StartTime'],
        format='%H:%M:%S'
    ).dt.hour

    records_by_hour = (
        filtered_data.groupby('StartHour')
        .size()
        .reindex(range(24), fill_value=0)
    )

    st.bar_chart(records_by_hour)

else:
    st.info('No hourly records to display.')

# CHART 3: DEMAND DISTRIBUTION

st.subheader('Demand Distribution')

if not filtered_data.empty:

    demand_values = filtered_data['Demand'].dropna()

    if not demand_values.empty and demand_values.nunique() > 1:

        demand_distribution = pd.cut(
            demand_values,
            bins=10
        ).value_counts().sort_index()

        demand_distribution.index = (
            demand_distribution.index.astype(str)
        )

        st.bar_chart(demand_distribution)

    elif not demand_values.empty:
        st.write('All available demand values are the same.')
    else:
        st.warning('No demand values are available.')

else:
    st.info('No demand data to display.')
