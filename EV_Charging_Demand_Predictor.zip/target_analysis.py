import pandas as pd

data = pd.read_csv('data/ev_charging_cleaned.csv')

columns = [
    'Vehicle Model',
    'Time of Day',
    'Day of Week',
    'Charger Type',
    'User Type'
]

for column in columns:
    print("\n", column)
    print(
        data.groupby(column)['Energy Consumed (kWh)']
        .agg(['mean', 'count'])
        .round(2)
    )