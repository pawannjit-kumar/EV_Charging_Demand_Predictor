
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

data = pd.read_csv('data/ev_charging_cleaned.csv')

print("Dataset Shape:", data.shape)

print("\nDataset Information:")
print(data.info())

print("\nStatistical Summary:")
print(data.describe())

print("\nEnergy Consumed Summary:")
print(data['Energy Consumed (kWh)'].describe())

# 1. Energy Consumption Distribution
plt.figure(figsize=(8, 5))
sns.histplot(data['Energy Consumed (kWh)'], kde=True)
plt.title('Distribution of Energy Consumed')
plt.xlabel('Energy Consumed (kWh)')
plt.ylabel('Frequency')
plt.savefig('data/energy_distribution.png')
plt.close()

# 2. Energy Consumption by Charger Type
plt.figure(figsize=(8, 5))
sns.boxplot(x=data['Charger Type'], y=data['Energy Consumed (kWh)'])
plt.title('Energy Consumption by Charger Type')
plt.xlabel('Charger Type')
plt.ylabel('Energy Consumed (kWh)')
plt.savefig('data/charger_type.png')
plt.close()

# 3. Average Energy Consumption by Time of Day
plt.figure(figsize=(8, 5))
sns.barplot(x=data['Time of Day'], y=data['Energy Consumed (kWh)'])
plt.title('Average Energy Consumption by Time of Day')
plt.xlabel('Time of Day')
plt.ylabel('Average Energy Consumed (kWh)')
plt.savefig('data/time_of_day.png')
plt.close()

# 4. Battery Capacity vs Energy Consumed
plt.figure(figsize=(8, 5))
sns.scatterplot(
    x=data['Battery Capacity (kWh)'],
    y=data['Energy Consumed (kWh)']
)
plt.title('Battery Capacity vs Energy Consumed')
plt.xlabel('Battery Capacity (kWh)')
plt.ylabel('Energy Consumed (kWh)')
plt.savefig('data/battery_capacity.png')
plt.close()

# 5. Average Energy Consumption by Day of Week
plt.figure(figsize=(8, 5))
sns.barplot(x=data['Day of Week'], y=data['Energy Consumed (kWh)'])
plt.title('Average Energy Consumption by Day of Week')
plt.xlabel('Day of Week')
plt.ylabel('Average Energy Consumed (kWh)')
plt.xticks(rotation=45)
plt.tight_layout()
plt.savefig('data/day_of_week.png')
plt.close()

print("\nAll five graphs saved successfully in the data folder.")
