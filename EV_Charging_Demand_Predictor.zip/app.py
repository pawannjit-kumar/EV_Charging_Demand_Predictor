
import streamlit as st
import pandas as pd
import numpy as np
import plotly.express as px
import joblib
from datetime import date, time

st.set_page_config(
    page_title="EV Charging Intelligence",
    page_icon="⚡",
    layout="wide"
)

st.markdown("""
<style>
.stApp {
    background: #0b1120;
    color: #e5edf7;
}
[data-testid="stSidebar"] {
    background: #111a2e;
}
h1, h2, h3 {
    color: #f1f5f9;
}
[data-testid="stMetric"] {
    background: #162238;
    border: 1px solid #273956;
    padding: 18px;
    border-radius: 12px;
}
[data-testid="stMetricLabel"] {
    color: #a7b8cf;
}
[data-testid="stMetricValue"] {
    color: #45e0b1;
}
div.stButton > button {
    background: #12b886;
    color: #07111f;
    border-radius: 8px;
    border: none;
    font-weight: 600;
}
.block-container {
    padding-top: 1.5rem;
    padding-bottom: 2rem;
}
</style>
""", unsafe_allow_html=True)


@st.cache_data
def load_data():
    data = pd.read_csv("data/ChargingRecords.csv")
    data["StartDatetime"] = pd.to_datetime(
        data["StartDatetime"], errors="coerce"
    )
    data["Demand"] = pd.to_numeric(data["Demand"], errors="coerce")
    data["Duration"] = pd.to_numeric(data["Duration"], errors="coerce")
    data["StartHour"] = pd.to_numeric(
        data["StartTime"].astype(str).str.split(":").str[0],
        errors="coerce"
    )
    data["DayName"] = data["StartDatetime"].dt.day_name()
    return data


@st.cache_resource
def load_model():
    return joblib.load("best_model.pkl")


data = load_data()
model = load_model()

st.sidebar.title("⚡ EV Intelligence")
st.sidebar.caption("Charging Demand Analytics")
st.sidebar.divider()

page = st.sidebar.radio(
    "NAVIGATION",
    [
        "Overview",
        "Demand Prediction",
        "Advanced Analytics",
        "Data Explorer",
        "Model Performance"
    ]
)

st.sidebar.divider()
st.sidebar.subheader("Dashboard Filters")

companies = ["All Companies"] + sorted(
    data["ChargerCompany"].dropna().unique().tolist()
)
charger_types = ["All Types"] + sorted(
    data["ChargerType"].dropna().unique().tolist()
)
locations = ["All Locations"] + sorted(
    data["Location"].dropna().astype(str).unique().tolist()
)

company_filter = st.sidebar.selectbox("Charger Company", companies)
type_filter = st.sidebar.selectbox("Charger Type", charger_types)
location_filter = st.sidebar.selectbox("Location", locations)

valid_dates = data["StartDatetime"].dropna()

if not valid_dates.empty:
    min_date = valid_dates.min().date()
    max_date = valid_dates.max().date()
    selected_dates = st.sidebar.date_input(
        "Charging Date Range",
        value=(min_date, max_date),
        min_value=min_date,
        max_value=max_date
    )
else:
    selected_dates = ()

filtered_data = data.copy()

if company_filter != "All Companies":
    filtered_data = filtered_data[
        filtered_data["ChargerCompany"] == company_filter
    ]

if type_filter != "All Types":
    filtered_data = filtered_data[
        filtered_data["ChargerType"] == type_filter
    ]

if location_filter != "All Locations":
    filtered_data = filtered_data[
        filtered_data["Location"].astype(str) == location_filter
    ]

if isinstance(selected_dates, (tuple, list)) and len(selected_dates) == 2:
    filtered_data = filtered_data[
        filtered_data["StartDatetime"].dt.date.between(
            selected_dates[0], selected_dates[1]
        )
    ]


def show_header(title, subtitle):
    st.title(title)
    st.caption(subtitle)


def show_kpis(frame):
    c1, c2, c3, c4 = st.columns(4)
    c1.metric("Charging Records", f"{len(frame):,}")
    c2.metric("Locations", frame["Location"].nunique())
    c3.metric("Charger Types", frame["ChargerType"].nunique())
    c4.metric(
        "Average Demand",
        f"{frame['Demand'].mean():.2f}"
        if frame["Demand"].notna().any() else "N/A"
    )


if filtered_data.empty:
    st.warning("No records match the selected filters.")
    st.stop()


if page == "Overview":

    show_header(
        "⚡ EV Charging Intelligence",
        "Monitor charging activity and explore demand patterns."
    )

    show_kpis(filtered_data)
    st.divider()

    left, right = st.columns(2)

    with left:
        st.subheader("Average Demand by Charger Type")
        type_demand = (
            filtered_data.groupby("ChargerType", as_index=False)["Demand"]
            .mean()
        )
        fig = px.bar(
            type_demand,
            x="ChargerType",
            y="Demand",
            color="Demand",
            color_continuous_scale="Teal"
        )
        fig.update_layout(template="plotly_dark")
        st.plotly_chart(fig, use_container_width=True)

    with right:
        st.subheader("Charging Activity by Hour")
        hourly = (
            filtered_data.groupby("StartHour")
            .size()
            .reindex(range(24), fill_value=0)
            .rename_axis("Hour")
            .reset_index(name="Records")
        )
        fig = px.area(
            hourly,
            x="Hour",
            y="Records",
            markers=True,
            color_discrete_sequence=["#45e0b1"]
        )
        fig.update_layout(template="plotly_dark")
        st.plotly_chart(fig, use_container_width=True)

    left, right = st.columns(2)

    with left:
        st.subheader("Demand Distribution")
        fig = px.histogram(
            filtered_data.dropna(subset=["Demand"]),
            x="Demand",
            nbins=25,
            color_discrete_sequence=["#38bdf8"]
        )
        fig.update_layout(template="plotly_dark")
        st.plotly_chart(fig, use_container_width=True)

    with right:
        st.subheader("Busiest Locations")
        busiest = (
            filtered_data.groupby("Location")
            .size()
            .nlargest(10)
            .sort_values()
            .reset_index(name="Records")
        )
        fig = px.bar(
            busiest,
            x="Records",
            y="Location",
            orientation="h",
            color="Records",
            color_continuous_scale="Teal"
        )
        fig.update_layout(template="plotly_dark")
        st.plotly_chart(fig, use_container_width=True)

    st.subheader("Quick Insights")

    valid_hours = filtered_data["StartHour"].dropna()

    if not valid_hours.empty:
        peak_hour = int(valid_hours.value_counts().idxmax())
        st.info(f"Busiest charging hour: {peak_hour:02d}:00")

    if not filtered_data["Location"].dropna().empty:
        busiest_location = filtered_data["Location"].value_counts().idxmax()
        st.info(f"Busiest location by record count: {busiest_location}")


elif page == "Demand Prediction":

    show_header(
        "🎯 Demand Prediction",
        "Predict charging demand using your trained machine learning model."
    )

    st.info("Enter the charging details and click Predict Demand.")

    with st.form("prediction_form"):

        c1, c2 = st.columns(2)

        with c1:
            charger_id = st.selectbox(
                "Charger ID",
                sorted(data["ChargerID"].dropna().unique().tolist())
            )
            company = st.selectbox(
                "Charger Company",
                sorted(data["ChargerCompany"].dropna().unique().tolist())
            )
            location = st.selectbox(
                "Location",
                sorted(data["Location"].dropna().astype(str).unique().tolist())
            )

        with c2:
            charger_type = st.selectbox(
                "Charger Type",
                sorted(data["ChargerType"].dropna().unique().tolist())
            )
            charging_date = st.date_input("Charging Date", value=date.today())
            charging_time = st.time_input(
                "Charging Start Time",
                value=time(9, 0)
            )

        submitted = st.form_submit_button("⚡ Predict Demand")

    if submitted:

        input_data = pd.DataFrame([{
            "ChargerID": charger_id,
            "ChargerCompany": company,
            "Location": location,
            "ChargerType": charger_type,
            "StartHour": charging_time.hour,
            "StartDay": charging_date.weekday()
        }])

        prediction = float(model.predict(input_data)[0])

        q33 = data["Demand"].quantile(0.33)
        q66 = data["Demand"].quantile(0.66)

        if prediction <= q33:
            demand_level = "Low"
        elif prediction <= q66:
            demand_level = "Moderate"
        else:
            demand_level = "High"

        st.divider()

        c1, c2 = st.columns(2)
        c1.metric("Predicted Charging Demand", f"{prediction:.2f}")
        c2.metric("Demand Category", demand_level)

        st.success("Prediction completed successfully.")
        st.subheader("Selected Charging Details")
        st.dataframe(input_data, use_container_width=True)

        st.caption(
            "The demand category is based on the dataset's demand percentiles. "
            "It is not a probability or a guaranteed future outcome."
        )


elif page == "Advanced Analytics":

    show_header(
        "📊 Advanced Analytics",
        "Explore demand across locations, companies, days, and hours."
    )

    left, right = st.columns(2)

    with left:
        st.subheader("Average Demand by Location")
        location_demand = (
            filtered_data.groupby("Location", as_index=False)["Demand"]
            .mean()
            .sort_values("Demand", ascending=False)
        )
        fig = px.bar(
            location_demand,
            x="Location",
            y="Demand",
            color="Demand",
            color_continuous_scale="Viridis"
        )
        fig.update_layout(template="plotly_dark")
        st.plotly_chart(fig, use_container_width=True)

    with right:
        st.subheader("Average Demand by Company")
        company_demand = (
            filtered_data.groupby("ChargerCompany", as_index=False)["Demand"]
            .mean()
        )
        fig = px.bar(
            company_demand,
            x="ChargerCompany",
            y="Demand",
            color="Demand",
            color_continuous_scale="Teal"
        )
        fig.update_layout(template="plotly_dark")
        st.plotly_chart(fig, use_container_width=True)

    st.subheader("Average Demand by Day and Hour")

    heat_data = filtered_data.dropna(
        subset=["DayName", "StartHour", "Demand"]
    ).copy()

    day_order = [
        "Monday", "Tuesday", "Wednesday", "Thursday",
        "Friday", "Saturday", "Sunday"
    ]

    if not heat_data.empty:
        heatmap = heat_data.pivot_table(
            index="DayName",
            columns="StartHour",
            values="Demand",
            aggfunc="mean"
        ).reindex(day_order)

        fig = px.imshow(
            heatmap,
            labels={
                "x": "Hour of Day",
                "y": "Day of Week",
                "color": "Average Demand"
            },
            aspect="auto",
            color_continuous_scale="Viridis"
        )
        fig.update_layout(template="plotly_dark")
        st.plotly_chart(fig, use_container_width=True)

    st.subheader("Numeric Feature Correlation")

    numeric_columns = filtered_data.select_dtypes(
        include=np.number
    ).columns.tolist()

    if len(numeric_columns) >= 2:
        correlation = filtered_data[numeric_columns].corr()
        fig = px.imshow(
            correlation,
            text_auto=".2f",
            aspect="auto",
            color_continuous_scale="RdBu_r",
            zmin=-1,
            zmax=1
        )
        fig.update_layout(template="plotly_dark")
        st.plotly_chart(fig, use_container_width=True)


elif page == "Data Explorer":

    show_header(
        "🗂️ Data Explorer",
        "Inspect records, identify missing data, and export filtered results."
    )

    c1, c2, c3 = st.columns(3)
    c1.metric("Filtered Rows", f"{len(filtered_data):,}")
    c2.metric("Missing Cells", f"{int(filtered_data.isna().sum().sum()):,}")
    c3.metric("Duplicate Rows", f"{int(filtered_data.duplicated().sum()):,}")

    st.subheader("Filtered Charging Records")
    st.dataframe(filtered_data, use_container_width=True, height=420)

    csv_data = filtered_data.to_csv(index=False).encode("utf-8")

    st.download_button(
        "⬇️ Download Filtered CSV",
        data=csv_data,
        file_name="filtered_ev_charging_records.csv",
        mime="text/csv"
    )

    st.subheader("Missing Values by Column")

    missing = (
        filtered_data.isna().sum()
        .rename("Missing Values")
        .reset_index()
        .rename(columns={"index": "Column"})
    )

    missing = missing[missing["Missing Values"] > 0]

    if not missing.empty:
        fig = px.bar(
            missing,
            x="Column",
            y="Missing Values",
            color="Missing Values"
        )
        fig.update_layout(template="plotly_dark")
        st.plotly_chart(fig, use_container_width=True)
    else:
        st.success("No missing values found in the filtered records.")


elif page == "Model Performance":

    show_header(
        "🧠 Model Performance",
        "Compare the evaluation results from your model training."
    )

    try:
        results = pd.read_csv("model_results.csv")
        st.dataframe(results.round(4), use_container_width=True)

        metric = st.selectbox(
            "Evaluation Metric",
            ["MAE", "RMSE", "R2 Score"]
        )

        fig = px.bar(
            results,
            x="Model",
            y=metric,
            color="Model",
            text_auto=".3f"
        )
        fig.update_layout(template="plotly_dark")
        st.plotly_chart(fig, use_container_width=True)

        if metric == "R2 Score":
            best_row = results.loc[results[metric].idxmax()]
        else:
            best_row = results.loc[results[metric].idxmin()]

        st.info(
            f"Best model for {metric}: {best_row['Model']} "
            f"({best_row[metric]:.3f})"
        )

    except FileNotFoundError:
        st.warning("model_results.csv not found. Run model_training.py first.")


st.sidebar.divider()
st.sidebar.caption("EV Charging Intelligence | Machine Learning Project")
