
import pandas as pd
import joblib

from sklearn.compose import ColumnTransformer
from sklearn.preprocessing import OneHotEncoder
from sklearn.pipeline import Pipeline
from sklearn.ensemble import RandomForestRegressor, GradientBoostingRegressor
from sklearn.dummy import DummyRegressor
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score

# LOAD DATA

data = pd.read_csv('data/ChargingRecords.csv')
data = data.drop_duplicates()

data['StartDatetime'] = pd.to_datetime(data['StartDatetime'])
data['StartTime'] = pd.to_datetime(
    data['StartTime'], format='%H:%M:%S'
)
data['StartDay'] = pd.to_datetime(data['StartDay'])

# FEATURE ENGINEERING

data['StartHour'] = data['StartTime'].dt.hour
data['StartDay'] = data['StartDay'].dt.day_of_week

# SELECT FEATURES AND TARGET

features = [
    'ChargerID',
    'ChargerCompany',
    'Location',
    'ChargerType',
    'StartHour',
    'StartDay'
]

X = data[features].copy()
y = data['Demand']

# REMOVE MISSING VALUES

valid_rows = (
    X.notna().all(axis=1)
    & y.notna()
    & data['StartDatetime'].notna()
)

X = X.loc[valid_rows]
y = y.loc[valid_rows]
data = data.loc[valid_rows]

print('Rows available for training:', len(data), flush=True)

# SORT BY DATE

data = data.sort_values('StartDatetime')
X = X.loc[data.index]
y = y.loc[data.index]

# TRAIN-TEST SPLIT

split_index = int(len(data) * 0.8)

X_train = X.iloc[:split_index]
X_test = X.iloc[split_index:]

y_train = y.iloc[:split_index]
y_test = y.iloc[split_index:]

# PREPROCESSING

categorical_features = [
    'ChargerCompany',
    'Location',
    'ChargerType'
]

preprocessor = ColumnTransformer(
    transformers=[
        (
            'categories',
            OneHotEncoder(handle_unknown='ignore'),
            categorical_features
        )
    ],
    remainder='passthrough'
)

# MODELS

models = {
    'Baseline': DummyRegressor(strategy='mean'),
    'Random Forest': RandomForestRegressor(
        n_estimators=50,
        random_state=42,
        n_jobs=-1
    ),
  'Gradient Boosting': GradientBoostingRegressor(
    n_estimators=150,
    learning_rate=0.05,
    max_depth=3,
    random_state=42
)
}

results = []

# TRAIN AND EVALUATE

for name, model in models.items():

    print('\nStarting model:', name, flush=True)

    pipeline = Pipeline([
        ('preprocessor', preprocessor),
        ('model', model)
    ])

    pipeline.fit(X_train, y_train)

    predictions = pipeline.predict(X_test)

    mae = mean_absolute_error(y_test, predictions)
    rmse = mean_squared_error(y_test, predictions) ** 0.5
    r2 = r2_score(y_test, predictions)

    print('Model:', name)
    print('MAE:', round(mae, 2))
    print('RMSE:', round(rmse, 2))
    print('R2 Score:', round(r2, 3))

    results.append({
        'Model': name,
        'MAE': mae,
        'RMSE': rmse,
        'R2 Score': r2
    })

    if name == 'Gradient Boosting':
        joblib.dump(pipeline, 'best_model.pkl')

# SAVE RESULTS

pd.DataFrame(results).to_csv('model_results.csv', index=False)

print('\nModel results saved to model_results.csv')
print('Best model saved to best_model.pkl')
