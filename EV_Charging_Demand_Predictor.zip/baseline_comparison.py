
import pandas as pd

from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score
from sklearn.dummy import DummyRegressor
from sklearn.ensemble import GradientBoostingRegressor
from sklearn.compose import ColumnTransformer
from sklearn.preprocessing import OneHotEncoder
from sklearn.pipeline import Pipeline

# Load Dataset

data = pd.read_csv('data/ev_charging_valid.csv')

X = data[
    [
        'Battery Capacity (kWh)',
        'State of Charge (Start %)',
        'Distance Driven (since last charge) (km)',
        'Temperature (°C)',
        'Vehicle Age (years)',
        'Vehicle Model',
        'Charging Station Location',
        'Time of Day',
        'Day of Week',
        'Charger Type',
        'User Type'
    ]
]

y = data['Energy Consumed (kWh)']

numerical_features = [
    'Battery Capacity (kWh)',
    'State of Charge (Start %)',
    'Distance Driven (since last charge) (km)',
    'Temperature (°C)',
    'Vehicle Age (years)'
]

categorical_features = [
    'Vehicle Model',
    'Charging Station Location',
    'Time of Day',
    'Day of Week',
    'Charger Type',
    'User Type'
]

preprocessor = ColumnTransformer(
    transformers=[
        ('cat', OneHotEncoder(handle_unknown='ignore'), categorical_features),
        ('num', 'passthrough', numerical_features)
    ]
)

X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=42
)

models = {
    'Baseline': DummyRegressor(strategy='mean'),
    'Gradient Boosting': Pipeline(
        steps=[
            ('preprocessor', preprocessor),
            ('model', GradientBoostingRegressor(random_state=42))
        ]
    )
}

for name, model in models.items():
    model.fit(X_train, y_train)
    predictions = model.predict(X_test)

    print('\nModel:', name)
    print('MAE:', round(mean_absolute_error(y_test, predictions), 2))
    print('RMSE:', round(mean_squared_error(y_test, predictions) ** 0.5, 2))
    print('R2 Score:', round(r2_score(y_test, predictions), 3))

