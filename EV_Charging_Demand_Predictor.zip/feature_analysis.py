
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

data = pd.read_csv('data/ev_charging_cleaned.csv')

columns = [
    'Battery Capacity (kWh)',
    'State of Charge (Start %)',
    'Distance Driven (since last charge) (km)',
    'Temperature (°C)',
    'Vehicle Age (years)',
    'Energy Consumed (kWh)'
]

correlation = data[columns].corr()

print("Correlation with Energy Consumed:")
print(correlation['Energy Consumed (kWh)'].sort_values(ascending=False))

plt.figure(figsize=(9, 6))
sns.heatmap(correlation, annot=True, cmap='coolwarm', fmt='.2f')
plt.title('Feature Correlation Heatmap')
plt.tight_layout()
plt.savefig('data/feature_correlation.png')
plt.close()

print("\nCorrelation heatmap saved in the data folder.")
