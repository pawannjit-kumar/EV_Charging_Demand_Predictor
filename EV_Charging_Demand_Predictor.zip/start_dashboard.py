
import subprocess
import os

project_path = os.path.expanduser(
    "~/Downloads/EV_Charging_Demand_Predictor"
)

subprocess.Popen(
    [
        os.path.join(project_path, ".venv/bin/python"),
        "-m",
        "streamlit",
        "run",
        "app.py"
    ],
    cwd=project_path
)
